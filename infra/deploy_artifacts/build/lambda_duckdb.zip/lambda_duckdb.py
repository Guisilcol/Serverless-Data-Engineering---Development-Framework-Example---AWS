# Liap

def main(events, context):
    return {
        'code': 200,
        'message': 'Test message'
    }

if __name__ == '__main__':
    main(None, None)